# CarrotScript Testing Server

This is an package that create a local testing server so you can test a application or something else on your computer.

## Installation

To install this, we reccomend using PIP. Run the following on your terminal

```
pip3 install carrotscript
```

## Usage

To use this package, in a python file, run this:

```
from carrotscript import carrotscript
```

Then, it should ask a question:

```
What port do you want to create your local server in: 
```

Answer a port like:

```
What port do you want to create your local server in: 8080
```

Then it should give something like this:

```
Web Server is running at http://localhost:8080
Close this tab to exit
Logs:

```

Then visit http://localhost:8080 (or whatever yours is) and you got a web server

TIP: ``` cd ``` to a directory and create a ```index.html``` file in there. Then, create a testing server there



---

&#169; Greatly Gravitate
